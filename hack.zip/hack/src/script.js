// Mocking sensor data (simulates real-time updates)
const sensorData = {
  1: "empty",
  2: "empty",
  3: "booked",
  4: "empty",
  5: "booked",
  6: "empty",
};

// Refreshes the parking lot visualization
const refreshParkingLot = () => {
  for (let i = 1; i <= 6; i++) {
    const spot = document.getElementById(`spot-${i}`);
    if (sensorData[i] === "empty") {
      spot.classList.add("empty");
      spot.classList.remove("booked");
      spot.innerText = `Spot ${i}`;
    } else if (sensorData[i] === "booked") {
      spot.classList.add("booked");
      spot.classList.remove("empty");
      spot.innerText = `Spot ${i} (Booked)`;
    }
  }
};

// Books a parking spot based on its ID
const bookSpot = (id) => {
  if (sensorData[id] === "empty") {
    alert(
      `Spot ${id} has been booked! You have 5 minutes to reach the spot. If not, the status will reset.`
    );
    sensorData[id] = "booked";
    refreshParkingLot();

    // Reset the spot to empty after 5 minutes
    setTimeout(() => {
      sensorData[id] = "empty";
      refreshParkingLot();
    }, 300000); // 5 minutes
  } else {
    alert(`Spot ${id} is already booked!`);
  }
};

// Books a parking spot from the dashboard dropdown
const bookFromDashboard = () => {
  const spotSelector = document.getElementById("spot-selector");
  const selectedSpot = spotSelector.value;
  if (!selectedSpot) {
    alert("Please select a spot to book!");
    return;
  }
  bookSpot(parseInt(selectedSpot));
};

// Refresh parking lot initially
refreshParkingLot();
